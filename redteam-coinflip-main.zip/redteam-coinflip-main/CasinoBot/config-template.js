const abi = 'DELETE THIS STRING AND REPLACE'


const smartContractAddress = "SMART CONTRACT ADDRESS GOES HERE"

const casinoPrivateKey = "PRIVATE KEY OF WALLET OF CASINO GOES HERE"

const web3Provider = "WEB3 PROVIDER GOES HERE"

module.exports = {
	abi,
	smartContractAddress,
	casinoPrivateKey,
	web3Provider
}
# Setup front end -

*NOTE: Must install metmask on your browser!* <br />
*NOTE: must install node/npm*

1.) use your terminal to change directory to front end folder<br /> 
2.) run "npm install" to install dependencies <br />
3.) run "npm start" or "yarn start" (if you're using yarn) <br/>
4.) localhost:3000 should be working in your browser. Enjoy

import React, {Props} from 'react'


const GameResult=(props)=> {

       return (
              <div>
                {props.result}     
              </div>
       )
}

export default GameResult;

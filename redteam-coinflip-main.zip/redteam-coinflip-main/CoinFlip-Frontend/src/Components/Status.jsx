import React, {Props} from 'react'


const Status=(props)=> {
       
       return (
              <div>
                    {props.status}
              </div>
       )
}

export default Status;

# smartcontract-coinflip

[Casino Front End](CoinFlip-Frontend)
In this folder, you can find the files for Casino Front End to intereact with our smart contract.

[Casino Bot](CasinoBot)
In this folder, you can find the files to automate Casino actions using a bot that runs on Raspberry Pi 24/7. In addition, there is a script for the casino to deposit more money into the smart contract

[CoinFlip Smart Contract](CasinoSmartContract)
In this folder, you can find the files of our actual CoinFlip Smart Contract

[CoinFlip Smart Contract Testing](CasinoTesting)
In this folder, you can find the files to execute flow & phase testing for our smart contract.
